/* Musa Njabulo Mahlangu | Portfolio interactions
   No scroll listeners: header state, active links, reveals and counters all use IntersectionObserver. */
(() => {
  'use strict';

  const WHATSAPP_NUMBER = '27631413009';
  const EMAIL = 'musamahlangu1977@gmail.com';
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hasIO = 'IntersectionObserver' in window;
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  /* ---------- Fit ghost wordmarks to their container width ---------- */
  const fitTargets = $$('[data-fit-text]');
  const fitText = () => {
    fitTargets.forEach((el) => {
      const box = el.parentElement;
      const available = box.clientWidth;
      el.style.width = 'max-content';
      const current = parseFloat(getComputedStyle(el).fontSize);
      const natural = el.getBoundingClientRect().width;
      if (!available || !natural) return;
      const next = Math.min(current * (available / natural), 260);
      el.style.fontSize = `${next.toFixed(2)}px`;
    });
  };
  if (fitTargets.length) {
    const runFit = () => requestAnimationFrame(fitText);
    runFit();
    // Re-measure once the display font is actually in use, otherwise the fallback font's width sticks
    if (document.fonts && document.fonts.load) document.fonts.load('400 100px Anton').then(runFit, runFit);
    window.addEventListener('load', runFit, { once: true });
    if ('ResizeObserver' in window) {
      let lastWidth = 0;
      const ro = new ResizeObserver(([entry]) => {
        const w = Math.round(entry.contentRect.width);
        if (w !== lastWidth) { lastWidth = w; runFit(); }
      });
      ro.observe(fitTargets[0].parentElement);
    }
  }

  /* ---------- Header state ---------- */
  const header = $('.site-header');
  const sentinel = $('#top-sentinel');
  if (header && sentinel && hasIO) {
    new IntersectionObserver(([entry]) => {
      header.classList.toggle('is-scrolled', !entry.isIntersecting);
    }).observe(sentinel);
  }

  /* ---------- Active section links ---------- */
  const navLinks = $$('[data-nav-link]');
  // '#top' is watched too, so returning to the hero clears every highlight
  const sectionIds = ['#top', ...new Set(navLinks.map((a) => a.getAttribute('href')))];
  if (hasIO) {
    const spy = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const id = `#${entry.target.id}`;
        navLinks.forEach((a) => {
          const on = a.getAttribute('href') === id;
          a.classList.toggle('is-active', on);
          if (on) a.setAttribute('aria-current', 'location');
          else a.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sectionIds.forEach((id) => { const s = $(id); if (s) spy.observe(s); });
  }

  /* ---------- Mobile menu ---------- */
  const menu = $('#mobile-menu');
  const menuBtn = $('[data-menu-open]');
  if (menu && menuBtn && typeof menu.showModal === 'function') {
    menuBtn.addEventListener('click', () => { menu.showModal(); menuBtn.setAttribute('aria-expanded', 'true'); });
    menu.addEventListener('close', () => menuBtn.setAttribute('aria-expanded', 'false'));
    $$('[data-menu-close]', menu).forEach((b) => b.addEventListener('click', () => menu.close()));
    $$('a', menu).forEach((a) => a.addEventListener('click', () => menu.close()));
    menu.addEventListener('click', (e) => { if (e.target === menu) menu.close(); });
    const desktop = window.matchMedia('(min-width: 1120px)');
    desktop.addEventListener('change', (e) => { if (e.matches && menu.open) menu.close(); });
  }

  /* ---------- Scroll reveal ---------- */
  const revealEls = $$('[data-reveal]');
  if (reduceMotion || !hasIO) {
    revealEls.forEach((el) => el.classList.add('is-in'));
  } else {
    const revealer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-in');
        obs.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.1 });
    revealEls.forEach((el) => revealer.observe(el));
  }

  /* ---------- Count-up metrics ---------- */
  const counters = $$('[data-count]');
  if (!reduceMotion && hasIO && counters.length) {
    const render = (el, value) => { el.textContent = `${value}${el.dataset.suffix || ''}`; };
    counters.forEach((el) => render(el, 0));
    const counterIO = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        obs.unobserve(entry.target);
        const el = entry.target;
        const target = Number(el.dataset.count);
        const duration = 1400;
        const start = performance.now();
        const tick = (now) => {
          const p = Math.min((now - start) / duration, 1);
          render(el, Math.round(target * (1 - Math.pow(1 - p, 3))));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.6 });
    counters.forEach((el) => counterIO.observe(el));
  }

  /* ---------- Tabs (pricing) ---------- */
  const tabControllers = new Map();
  $$('[data-tabs]').forEach((list) => {
    const tabs = $$('[role="tab"]', list);
    const horizontalScroll = () => list.scrollWidth > list.clientWidth + 2;
    const select = (tab, { focus = false, animate = true } = {}) => {
      tabs.forEach((t) => {
        const on = t === tab;
        t.setAttribute('aria-selected', String(on));
        t.tabIndex = on ? 0 : -1;
        const panel = document.getElementById(t.getAttribute('aria-controls'));
        if (!panel) return;
        panel.hidden = !on;
        if (on && animate && !reduceMotion) {
          panel.classList.remove('is-entering');
          void panel.offsetWidth;
          panel.classList.add('is-entering');
        }
      });
      if (focus) tab.focus({ preventScroll: true });
      if (horizontalScroll()) {
        const left = tab.offsetLeft - (list.clientWidth - tab.offsetWidth) / 2;
        list.scrollTo({ left, behavior: reduceMotion ? 'auto' : 'smooth' });
      }
    };
    tabs.forEach((tab, i) => {
      tab.addEventListener('click', () => select(tab));
      tab.addEventListener('keydown', (e) => {
        const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
        let next = null;
        if (step) next = tabs[(i + step + tabs.length) % tabs.length];
        else if (e.key === 'Home') next = tabs[0];
        else if (e.key === 'End') next = tabs[tabs.length - 1];
        if (next) { e.preventDefault(); select(next, { focus: true }); }
      });
      tabControllers.set(tab.id, () => select(tab, { animate: false }));
    });
  });
  // Links that jump to a section and open a specific tab
  $$('[data-open-tab]').forEach((link) => {
    link.addEventListener('click', () => {
      const open = tabControllers.get(link.dataset.openTab);
      if (open) open();
    });
  });

  /* ---------- Service detail sheet ---------- */
  // Each service card carries its full list in a hidden .svc-detail block; the sheet shows it.
  const sheet = $('#svc-sheet');
  if (sheet && typeof sheet.showModal === 'function') {
    const sheetCta = $('#svc-sheet-cta');
    let sheetOpener = null;
    const openService = (key, trigger) => {
      const row = $(`.svc-card[data-service="${key}"]`);
      if (!row) return;
      const title = row.querySelector('.svc-title').textContent;
      sheetOpener = trigger;
      $('#svc-sheet-icon').innerHTML = row.querySelector('.svc-icon').innerHTML;
      $('#svc-sheet-title').textContent = title;
      $('#svc-sheet-desc').textContent = row.querySelector('.svc-desc').textContent;
      $('#svc-sheet-body').innerHTML = row.querySelector('.svc-detail').innerHTML;
      sheetCta.dataset.enquire = title;
      sheetCta.firstChild.textContent = `Enquire About ${title} `;
      sheet.showModal();
      $('[data-sheet-close]', sheet).focus();
    };
    $$('[data-open-service]').forEach((el) => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        openService(el.dataset.openService, el);
      });
    });
    $('[data-sheet-close]', sheet).addEventListener('click', () => sheet.close());
    sheet.addEventListener('click', (e) => { if (e.target === sheet) sheet.close(); });
    sheetCta.addEventListener('click', () => { sheetOpener = null; sheet.close(); });
    sheet.addEventListener('close', () => { if (sheetOpener) sheetOpener.focus({ preventScroll: true }); });
  }

  /* ---------- Enquiry prefill (service + package buttons) ---------- */
  const form = $('#enquiry-form');
  const fields = form ? {
    name: $('#f-name'), email: $('#f-email'), service: $('#f-service'), message: $('#f-message'),
  } : null;

  $$('[data-enquire]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (!fields) return;
      const choice = btn.dataset.enquire;
      const option = [...fields.service.options].find((o) => o.value === choice || o.text === choice);
      if (option) fields.service.value = option.value;
      clearError('service');
      if (!fields.message.value.trim()) {
        const kind = /package|retainer|training/i.test(choice) ? 'package' : 'service';
        fields.message.value = `I'd like to find out more about this ${kind}. `;
      }
      // Let the anchor scroll finish, then move focus without jumping
      window.setTimeout(() => fields.name.focus({ preventScroll: true }), reduceMotion ? 0 : 700);
    });
  });

  /* ---------- Contact form: validate, then compose to WhatsApp or email ---------- */
  const rules = {
    name: (v) => v.trim().length >= 2 || 'Please enter your name.',
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Please enter a valid email address, like name@example.com.',
    service: (v) => Boolean(v) || 'Please choose the service you need.',
    message: (v) => v.trim().length >= 10 || 'Please add a short description of at least 10 characters.',
  };
  function setError(key, msg) {
    const input = fields[key];
    const err = document.getElementById(`${input.id}-err`);
    input.setAttribute('aria-invalid', 'true');
    if (err) err.textContent = msg;
  }
  function clearError(key) {
    if (!fields) return;
    const input = fields[key];
    const err = document.getElementById(`${input.id}-err`);
    input.removeAttribute('aria-invalid');
    if (err) err.textContent = '';
  }
  function validate(key) {
    const result = rules[key](fields[key].value);
    if (result === true) { clearError(key); return true; }
    setError(key, result);
    return false;
  }

  if (form && fields) {
    const status = $('#form-status');
    let attempted = false;
    Object.keys(fields).forEach((key) => {
      const input = fields[key];
      input.addEventListener('blur', () => { if (attempted || input.value) validate(key); });
      input.addEventListener(key === 'service' ? 'change' : 'input', () => {
        if (input.getAttribute('aria-invalid') === 'true') validate(key);
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      attempted = true;
      status.className = 'form-status';
      status.textContent = '';
      const results = Object.keys(fields).map((key) => [key, validate(key)]);
      const firstInvalid = results.find(([, ok]) => !ok);
      if (firstInvalid) {
        fields[firstInvalid[0]].focus();
        status.classList.add('is-error');
        status.textContent = 'Please fix the highlighted fields and try again.';
        return;
      }

      const name = fields.name.value.trim();
      const email = fields.email.value.trim();
      const service = fields.service.value;
      const message = fields.message.value.trim();
      const body = `Hi Musa, my name is ${name}.\n\nService: ${service}\n\n${message}\n\nEmail: ${email}`;
      const channel = e.submitter && e.submitter.value === 'email' ? 'email' : 'whatsapp';

      if (channel === 'whatsapp') {
        const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(body)}`;
        const win = window.open(url, '_blank', 'noopener');
        if (!win) window.location.href = url;
        status.textContent = 'WhatsApp is opening with your message. Just press send. If nothing opened, message +27 63 141 3009 directly.';
      } else {
        const subject = `Website enquiry: ${service}`;
        window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        status.textContent = `Your email app is opening with your message. If it didn't, email ${EMAIL} directly.`;
      }
      status.classList.add('is-success');
    });
  }

  /* ---------- Copy email ---------- */
  $$('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(btn.dataset.copy);
        btn.classList.add('is-copied');
        btn.setAttribute('aria-label', 'Email address copied');
        window.setTimeout(() => { btn.classList.remove('is-copied'); btn.setAttribute('aria-label', 'Copy email address'); }, 1800);
      } catch (_) {
        window.location.href = `mailto:${btn.dataset.copy}`;
      }
    });
  });

})();
